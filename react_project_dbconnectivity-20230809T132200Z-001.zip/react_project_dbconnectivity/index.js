import express from 'express'
import cors from 'cors'
import mongoose from 'mongoose'
import testimonialsjson from './testimonials.json' assert {type: 'json'};
import coursesjson from './courses.json' assert {type: 'json'};
import aboutjson from './about.json' assert {type: 'json'};

const app = express();
app.use(express.json())
app.use(express.urlencoded())
app.use(cors())

mongoose.connect(
  "mongodb://127.0.0.1:27017/ComputerTrainingInstitute",
  { useNewUrlParser: true, useUnifiedTopology: true }
).then((res) => {
  console.log("Database connected successfully!")
}
);

const contactSchema = mongoose.Schema(
  {
    name: String,
    course: String,
    email: String,
    phone: String,
    description: String
  },
  {
    versionKey: false
  }
)

const testimonialSchema = mongoose.Schema(
  {
    text: String,
    student: String
  },
  {
    versionKey: false
  }
)

const Contact = new mongoose.model("Contact", contactSchema);
const Testimonial = new mongoose.model("Testimonial", testimonialSchema);


app.get("/", (req, res) => {
  res.send("<h1>Backend starts here</h1>")
}
)

app.get("/testimonials", (req, res) => {
  res.send(testimonialsjson);
}
)

app.get("/courses", (req, res) => {
  res.send(coursesjson);
}
)

app.get("/about", (req, res) => {
  res.send(aboutjson);
}
)

app.post("/contact", (req, res) => {
  console.log("data sent from frontend is: ");
  console.log(req.body);

  const contact = new Contact(
    {
      name: req.body.name,
      course: req.body.course,
      email: req.body.email,
      phone: req.body.phone,
      description: req.body.description
    }
  )

  contact.save().then((response) => {
    if (response) {
      console.log("Details submitted successfully")
      res.send({ message: "Details submitted successfully" })

    }
    else {
      console.log("Error in submitting details. Please try after sometime")
      res.send({ message: "Error in submitting details. Please try after sometime" })
    }
  });
}
)

app.listen(9002, () => {
  console.log("Server started at port no. 9002")
}
)